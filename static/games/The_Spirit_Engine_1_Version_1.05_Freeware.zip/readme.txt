The Spirit Engine 1, Version 1.05 Freeware, Build 632

Fanmade patch by https://aquellex.ws/

-All music-related events have been changed to prevent access violations (i.e., crashing)
-Anti-cheat has been removed
-Saving no longer costs gold (the footnote at Homestead reflects this)
-www.natomic.com changed to www.thespiritengine.com
-Old musician URLs changed to most up-to-date versions with the exception of Yoshiman as I am unaware of any of his personal portfolios at the moment 
-Players can no longer move HotG with the arrow keys during battle
-'Window maximized' has been changed to 'Full Screen' (i.e., the game will now actually full screen instead of "maximizing the window")
-Window will not minimize upon losing focus
-No graphical bugs during cutscenes
-Rainbow graphical glitch no longer appears if you open the Skills menu too soon upon entering a level
-Some typos fixed (Hailey's Glen, The Republican Government Building, Gigliana's Border, Clarke's Tower Ruins)
-Leftover MIDIs that played at Arachnid's Grove and encountering Mad Dog Davis have been removed
-Players will no longer lose unspent skill points to Djan
-Sharpshoot will no longer wander 30 degrees off-course at Blue Sapphire Bay
-Rock particles no longer hang at Kaikin Gorge
-Rare sprite bug upon killing Sham Tikki Shamans in The Leafy Underbrush no longer occur
-Black Ooze at The Inky Pit now has correct attributes
-Mad Dog Davis no longer appears as a graphical bug if you sneak too soon in Saline
-Silver Bullet now displays the correct bonus damage against Dune Wraiths
-The Mana Tidebreak now plays a formally unused track
-Tza Tze, Granael and the Pocket Dimension stop scaling to your party level after 35
-Rainbow is no longer bugged on the final boss during the 2nd & 3rd phases
-Chain Magic no longer bypasses the MDMZ Frontal Unit