About:

VGM2TFI is a small command-line tool that allows to extract OPN
instruments from *.vgm or *.vgz files and save them as a set of *.tfi files.
It can process one or few files, or a whole directory with all
subdirectories at once. The tool removes duplicates of the same instruments
from different files, also removes duplicates with different volume (keeps
the most loud versions only). Extracted instruments will be saved into the
tool's directory and will be named by name of original file with order number
of an instrument in a file, with *.tfi extension.

The tool supports YM2612 and YM2151 data, omiting some parameters that are
not supported by YM2203 and the TFI format.


Usage:

VGM2TFI FILENAME.VGM (or .VGZ) - process a VGM file
VGM2TFI FILE1.VGM FILE2.VGM .. - process a few of VGM files
VGM2TFI PATH\*                 - process all VGM files from a directory
                                 and its sub-directores


Notes:

The tool was tested with VGM v1.80 files. It wasn't crash tested, by
processing thousands of files at once, for example.
 
To compile the source code you'll need to get zlib library from
http://www.zlib.net/.


History:

v1.1 20.05.12 - YM2151 support
v1.0 26.01.08 - Initial release


mailto:shiru@mail.ru
http://shiru.untergrund.net