The syntax is:

`vgm2opm.exe inputfile.vgm > outputfile.opm`

.vgz is also accepted as an input file